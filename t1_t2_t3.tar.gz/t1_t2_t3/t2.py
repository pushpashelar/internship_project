import psycopg2
from datetime import datetime as dt
global cursor
global connection
def readconf(filename):
    fp=open(filename,'r')
    data,module={},''
    for i in fp.readlines():
        if(i!='\n'):
            if(i.strip()[0]=='['):
                module=(i.strip())[1:len(i.strip())-1]
                data[module]={}
            else:
                keyval=i.strip().split('=')
                data[module][keyval[0]]=keyval[1]
    confdata=data
    print(confdata['postgres']['host'])
    print(confdata['postgres']['port'])
    print(confdata['postgres']['database'])


    try:
       connection = psycopg2.connect(user =confdata['postgres']['user'],
                                  password = confdata['postgres']['password'],
                                  host = confdata['postgres']['host'],
                                  port = confdata['postgres']['port'],
                                  database =confdata['postgres']['database'])
       return connection
       #cursor = connection.cursor()
       #print(cursor)
       #return cursor
       #print("conection sucesfull")
    except (Exception, psycopg2.Error) as error :
      print ("Error while connecting to PostgreSQL", error)

#readconf('/root/data.conf')

