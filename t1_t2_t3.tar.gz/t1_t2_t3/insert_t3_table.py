import t2
import psycopg2
from datetime import datetime as dt
connection=t2.readconf('/root/data.conf')
print(connection)
cursor = connection.cursor()
status="yes"
currentDT = dt.now()
Timestring=(str(currentDT))

query =  "select rollno from t2 where status='no';"
cursor.execute(query)
r=cursor.fetchall()
#connection.commit()

for i in range(len(r)):
    query = "insert into t3(rollno,cur_time,status) values(%s, %s, %s);"
    data = (r[i],Timestring,status)
    cursor.execute(query, data)
    connection.commit()
    quer = "update t2 set status='yes' where rollno='"+str(r[i][0])+"';"
    print(quer)
    cursor.execute(quer)
    connection.commit()


print("record insert sucesful and update")




#closing database connection.
if(connection):
    cursor.close()
    connection.close()
    print("PostgreSQL connection is closed")
