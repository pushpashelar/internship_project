create table t1(rollno text,name text,email text,mbno text,PRIMARY KEY(rollno));

create table t2(rollno text,time text,status text,PRIMARY KEY(rollno),FOREIGN KEY (rollno) REFERENCES t1(rollno));


create table t3(rollno text,cur_time text,status text,PRIMARY KEY(rollno),FOREIGN KEY (rollno) REFERENCES t2(rollno));


insert into t1(rollno,name,email,mbno) values('17101','pooja','fwf@gmail.com','9080877656');
insert into t1(rollno,name,email,mbno) values('17154','pushpa','pushpa@gmail.com','9850921794');
insert into t1(rollno,name,email,mbno) values('17210','niki','dfga@gmail.com','8345566778');
insert into t1(rollno,name,email,mbno) values('17140','sonu','hhjkjka@gmail.com','9767787056');
insert into t1(rollno,name,email,mbno) values('17146','mona','jhkk@gmail.com','9867655433');

