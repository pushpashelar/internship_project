import t2
import psycopg2
from datetime import datetime as dt
connection=t2.readconf('/root/data.conf')
print(connection)
cursor = connection.cursor()
print("enter student info for inserting")
rno=input("")
status=input("")
currentDT = dt.now()
Timestring=(str(currentDT))

query =  "INSERT INTO t2(rollno,time,status) VALUES (%s, %s, %s);"
data = (rno,Timestring,status)

cursor.execute(query, data)
connection.commit()


print("record inserted sucesfully")


#closing database connection.
if(connection):
    cursor.close()
    connection.close()
    print("PostgreSQL connection is closed")


